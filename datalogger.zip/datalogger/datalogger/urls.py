"""datalogger URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from app.views import csv_list, csv_detail, upload_csv, send_email, toggle_deep_filter, locsau
from app.views import SensorAnalysisView, alarm_view,check_sensor_data,show_alarms, login_view , logout_view, register, home , settings_view, values, query_results, query
urlpatterns = [
    path('admin/', admin.site.urls),
    path('', login_view, name='login'),
    path('logout/', logout_view, name='logout'),
    path('register/', register,name='register' ),
    path('home/', home, name='home'),
    path('settings/', settings_view, name='settings'),
    path('values/', values, name='values'),
    path('query_results/', query_results, name='query_results'),
    path('query/', query, name='query'),
    path('csv_list/', csv_list, name='csv_list'),
    path('sensor_analysis/', SensorAnalysisView.as_view(), name='sensor_analysis'),
    path('alarms/', show_alarms, name='show_alarms'),
    path('check-sensor-data/', check_sensor_data, name='check_sensor_data'),
    path('alarm/', alarm_view, name='alarm'),
    path('csv/<str:filename>/', csv_detail, name='csv_detail'),
    path('upload/', upload_csv, name='upload_csv'),
    path('send_email/', send_email, name='send_email'),
    path('toggle_deep_filter', toggle_deep_filter, name='toggle_deep_filter'),
    path('locsau', locsau, name='locsau'),


]
