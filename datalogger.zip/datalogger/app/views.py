from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from .models import CustomUser
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from .models import Sensor1, Sensor2
import os
def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = UserCreationForm()
    return render(request, 'register.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            return render(request, 'login.html', {'error': 'Invalid credentials'})
    else:
        return render(request, 'login.html')

def logout_view(request):
    logout(request)
    return redirect('login')
def home(request):
    return render(request,'home.html' )
# Create your views here.
from django.contrib import messages
import matplotlib.pyplot as plt
from django.conf import settings
def query_results(request):
    table = request.GET.get('table')
    start_time = request.GET.get('start_time')
    end_time = request.GET.get('end_time')

    # Truy vấn dữ liệu quá khứ tương ứng với bảng được chọn
    if table == 'Sensor1':
        queried_data = Sensor1.objects.filter(timestamp__range=[start_time, end_time])
    elif table == 'Sensor2':
        queried_data = Sensor2.objects.filter(timestamp__range=[start_time, end_time])
    else:
        queried_data = []

    return render(request, 'query_results.html', {'data': queried_data, 'table': table})
def query(request):
    return render(request,'query.html' )
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score


import numpy as np

def values(request):
    sensor1_values = Sensor1.objects.order_by('-timestamp')[:5]
    sensor2_values = Sensor2.objects.order_by('-timestamp')[:5]

    timestamps1 = []
    temperatures1 = []
    humidities1 = []

    for sensor1 in sensor1_values:
        timestamps1.append(sensor1.timestamp)
        temperatures1.append(sensor1.temperature)
        humidities1.append(sensor1.humidity)

    timestamps2 = []
    temperatures2 = []
    humidities2 = []

    for sensor2 in sensor2_values:
        timestamps2.append(sensor2.timestamp)
        temperatures2.append(sensor2.temperature)
        humidities2.append(sensor2.humidity)

    plt.figure(figsize=(10, 6))

    plt.subplot(2, 1, 1)
    plt.plot(timestamps1, temperatures1, 'r-', label='Sensor 1 Temperature(C)')
    plt.plot(timestamps1, humidities1, 'b-', label='Sensor 1 Humidity(%)')
    plt.xlabel('Timestamp')
    plt.ylabel('Giá trị')
    plt.title('Sensor 1 Data')
    plt.legend()

    plt.subplot(2, 1, 2)
    plt.plot(timestamps2, temperatures2, 'r-', label='Sensor 2 Temperature(C)')
    plt.plot(timestamps2, humidities2, 'b-', label='Sensor 2 Humidity(%)')
    plt.xlabel('Timestamp')
    plt.ylabel('Giá trị')
    plt.title('Sensor 2 Data')
    plt.legend()

    plt.tight_layout()

    # Chuyển đổi biểu đồ thành hình ảnh
    chart_image = get_chart_image(plt)

    return render(request, 'value.html', {'sensor1_values': sensor1_values, 'sensor2_values': sensor2_values, 'chart_image': chart_image})

def get_chart_image(plt):
    from io import BytesIO
    import base64

    buffer = BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)

    chart_image = base64.b64encode(buffer.getvalue()).decode('utf-8')

    buffer.close()  # Đóng buffer để giải phóng tài nguyên
    plt.clf()  # Xóa biểu đồ từ bộ nhớ

    return chart_image
import pandas as pd
from django.http import HttpResponse
from django.views import View
from django.template import loader
class SensorAnalysisView(View):
    def get(self, request):
        # Lấy dữ liệu từ bảng Sensor1
        data = Sensor1.objects.all().values('temperature', 'humidity', 'timestamp')

        # Tạo DataFrame từ dữ liệu
        df = pd.DataFrame.from_records(data)

        # Chuyển đổi timestamp thành đối tượng datetime
        df['timestamp'] = pd.to_datetime(df['timestamp'])

        # Phân tích dữ liệu
        temperature_mean = df['temperature'].mean()
        humidity_mean = df['humidity'].mean()
        temperature_std = df['temperature'].std()
        humidity_std = df['humidity'].std()

        # Dự đoán kết quả tiếp theo (ví dụ)
        next_prediction = np.random.rand()

        # Chuẩn bị dữ liệu để truyền vào template
        context = {
            'temperature_mean': temperature_mean,
            'humidity_mean': humidity_mean,
            'temperature_std': temperature_std,
            'humidity_std': humidity_std,
            'next_prediction': next_prediction
        }

        # Load template và render với context
        template = loader.get_template('sensor_analysis.html')
        html = template.render(context)

        return HttpResponse(html)

import paho.mqtt.client as mqtt

# Khởi tạo một client MQTT
client = mqtt.Client()

# Thiết lập thông tin của máy chủ MQTT
MQTT_SERVER = 'broker.emqx.io'
MQTT_PORT = 1883

MQTT_KEEPALIVE = 60
# Thiết lập thông tin đăng nhập (nếu cần)
#client.username_pw_set(MQTT_USER, MQTT_PASSWORD)

# Kết nối tới máy chủ MQTT
#client.connect(MQTT_SERVER, MQTT_PORT, MQTT_KEEPALIVE)
import json 
def settings_view(request):
    if request.method == 'POST':
        topic_sensor1 = 'port1'
        topic_sensor2 = 'port2'

        # Kiểm tra xem liệu dữ liệu của sensor1 đã được điền vào biểu mẫu hay không
        if all(key in request.POST for key in ['sensor1_param1', 'sensor1_param2', 'sensor1_param3', 'sensor1_param4']):
            # Lấy dữ liệu từ biểu mẫu cho Sensor 1
            sensor1_param1 = float(request.POST.get('sensor1_param1'))
            sensor1_param2 = float(request.POST.get('sensor1_param2'))
            sensor1_param3 = float(request.POST.get('sensor1_param3'))
            sensor1_param4 = float(request.POST.get('sensor1_param4'))

            # Lưu dữ liệu Sensor 1 vào cơ sở dữ liệu
            sensor1_data = Sensor1(sensor_id=1, param1=sensor1_param1, param2=sensor1_param2, param3=sensor1_param3)
            sensor1_data.save()

            # Gửi dữ liệu của sensor1 qua MQTT
            sensor1_data_mqtt = {
                'param1': sensor1_param1,
                'param2': sensor1_param2,
                'param3': sensor1_param3,
                'param4': sensor1_param4,
            }
            client.publish(topic_sensor1, json.dumps(sensor1_data_mqtt))

        # Kiểm tra xem liệu dữ liệu của sensor2 đã được điền vào biểu mẫu hay không
        if all(key in request.POST for key in ['sensor2_param1', 'sensor2_param2', 'sensor2_param3','sensor2_param4']):
            # Lấy dữ liệu từ biểu mẫu cho Sensor 2
            sensor2_param1 = float(request.POST.get('sensor2_param1'))
            sensor2_param2 = float(request.POST.get('sensor2_param2'))
            sensor2_param3 = float(request.POST.get('sensor2_param3'))
            sensor2_param4 = float(request.POST.get('sensor2_param4'))

            # Lưu dữ liệu Sensor 2 vào cơ sở dữ liệu
            sensor2_data = Sensor2(sensor_id=2, param1=sensor2_param1, param2=sensor2_param2, param3=sensor2_param3)
            sensor2_data.save()

            # Gửi dữ liệu của sensor2 qua MQTT
            sensor2_data_mqtt = {
                'param1': sensor2_param1,
                'param2': sensor2_param2,
                'param3': sensor2_param3,
                'param4': sensor2_param4,
            }
            client.publish(topic_sensor2, json.dumps(sensor2_data_mqtt))

        messages.success(request, 'Cài đặt thành công!')
        return redirect('home')

    return render(request, 'settings.html')
from django.shortcuts import render
from django.shortcuts import render
from .models import Alarm

def show_alarms(request):
    alarms = Alarm.objects.all()  # Lấy tất cả các đối tượng cảnh báo từ cơ sở dữ liệu
    context = {
        'alarms': alarms
    }
    return render(request, 'show_alarms.html', context)

from django.shortcuts import render, redirect
from .models import Sensor1

def check_sensor_data(request):
    sensor_data = Sensor1.objects.last()

    # Kiểm tra giá trị nhiệt độ và độ ẩm
    MAX_TEMPERATURE = 30
    MAX_HUMIDITY = 70

    if sensor_data.temperature > MAX_TEMPERATURE or sensor_data.humidity > MAX_HUMIDITY:
        sensor_data.exceeded_threshold = True
        sensor_data.save()
        return redirect('alarm')

    return render(request, 'normal.html', {'sensor_data': sensor_data})

def alarm_view(request):
    sensor1_values = Sensor1.objects.latest()
    sensor2_values = Sensor2.objects.latest()
    return render(request, 'alarm.html',{'sensor1_values': sensor1_values, 'sensor2_values': sensor2_values})
import os
import csv
from django.shortcuts import render

def csv_list(request):
    csv_directory = 'E:\\Doan2\\FTP'
    csv_files = [f for f in os.listdir(csv_directory) if f.endswith('.csv')]

    context = {'csv_files': csv_files}
    return render(request, 'csv_list.html', context)

def csv_detail(request, filename):
    csv_directory = 'E:\\Doan2\\FTP'
    csv_path = os.path.join(csv_directory, filename)

    # Đọc nội dung từ file CSV
    records = []
    with open(csv_path, 'r') as file:
        csv_reader = csv.reader(file)
        for row in csv_reader:
            records.append(row)

    context = {
        'filename': filename,
        'records': records,
    }
    return render(request, 'csv_detail.html', context)
import os
from ftplib import FTP
from django.shortcuts import render, redirect

def upload_csv(request):
    if request.method == 'POST':
        # Lấy file được tải lên từ request
        csv_file = request.FILES.get('csv_file')

        # Lấy file CSV được chọn từ danh sách
        selected_csv = request.POST.get('csv_list')

        if csv_file:
            # Lưu file tạm thời lên máy chủ
            temp_path = 'E:\\Doan2\\FTP' + csv_file.name
            with open(temp_path, 'wb') as file:
                for chunk in csv_file.chunks():
                    file.write(chunk)

            # Gửi file qua FTP
            ftp_host = 'ftp.example.com'
            ftp_username = 'your-ftp-username'
            ftp_password = 'your-ftp-password'
            ftp_directory = '/path/on/ftp/server'

            send_csv_to_ftp(temp_path, ftp_host, ftp_username, ftp_password, ftp_directory)

            # Xóa file tạm thời
            os.remove(temp_path)

            # Chuyển hướng người dùng sau khi gửi thành công
            return redirect('upload_success')

        elif selected_csv:
            # Gửi file CSV được chọn qua FTP
            ftp_host = 'ftp.example.com'
            ftp_username = 'your-ftp-username'
            ftp_password = 'your-ftp-password'
            ftp_directory = '/path/on/ftp/server'

            send_csv_to_ftp(selected_csv, ftp_host, ftp_username, ftp_password, ftp_directory)

            # Chuyển hướng người dùng sau khi gửi thành công
            return redirect('upload_success')

    # Lấy danh sách các file CSV trong thư mục cụ thể
    csv_directory = 'E:\\Doan2\\FTP'
    csv_files = [f for f in os.listdir(csv_directory) if f.endswith('.csv')]

    return render(request, 'upload_csv.html', {'csv_files': csv_files})

def send_csv_to_ftp(csv_path, ftp_host, ftp_username, ftp_password, ftp_directory):
    ftp = FTP(ftp_host)
    ftp.login(user=ftp_username, passwd=ftp_password)
    ftp.cwd(ftp_directory)

    with open(csv_path, 'rb') as file:
        ftp.storbinary(f'STOR {os.path.basename(csv_path)}', file)

    ftp.quit()

def upload_success(request):
    return render(request, 'home.html')
from django.core.mail import EmailMessage
from django.template.loader import render_to_string
import csv

import os
import csv
from django.shortcuts import render
from django.core.mail import EmailMessage
from django.conf import settings

csv_directory = 'E:\\Doan2\\FTP'

def get_csv_files(csv_directory):
    csv_files = []
    for filename in os.listdir(csv_directory):
        if filename.endswith('.csv'):
            csv_files.append(filename)
    return csv_files

def send_email(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        selected_file = request.POST.get('selected_file')
        csv_file_path = os.path.join(csv_directory, selected_file)
        
        # Xử lý file CSV
        with open(csv_file_path, 'r') as file:
            csv_data = file.read()
        # Thực hiện các thao tác khác với dữ liệu CSV
        
        # Gửi email
        email_subject = 'Dữ liệu từ file CSV'
        email_body = 'Đây là dữ liệu từ file CSV đã chọn.'
        email = EmailMessage(email_subject, email_body, settings.DEFAULT_FROM_EMAIL, [email])
        email.attach(selected_file, csv_data, 'text/csv')
        email.send()
        
        return render(request, 'confirmation.html')
    
    # Nếu method là GET, render trang web với danh sách file CSV có sẵn
    csv_files = get_csv_files(csv_directory)
    return render(request, 'email_template.html', {'csv_files': csv_files})

from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt


import paho.mqtt.client as mqtt
@csrf_exempt
def toggle_deep_filter(request):
    if request.method == 'POST':
        enable = request.POST.get('enable')  # Lấy giá trị 'enable' từ request POST
        # Code xử lý bật/tắt chế độ lọc sâu tại đây

        # Kết nối tới MQTT broker
        client = mqtt.Client()
        client.connect("broker.emqx.io", 1883)  # Thay đổi địa chỉ và cổng broker MQTT của bạn
#MQTT protocol uses Wi-Fi.
#Bluetooth Low Energy Protocol Stack utilizes Bluetooth.
        if enable == 'true':
            # Gửi thông tin cho phép lọc sâu đến một topic MQTT
            client.publish("filter/deep", "enable")
            return JsonResponse({'status': 'success', 'message': 'Chế độ lọc sâu đã được bật'})
        else:
            # Gửi thông tin không cho phép lọc sâu đến một topic MQTT
            client.publish("filter/deep", "disable")
            return JsonResponse({'status': 'success', 'message': 'Chế độ lọc sâu đã được tắt'})

    return JsonResponse({'status': 'error', 'message': 'Invalid request method'})
def locsau(request):
    return render(request,'locsau.html')