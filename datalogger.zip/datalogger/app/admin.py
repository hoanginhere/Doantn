from django.contrib import admin

# Register your models here.
from .models import Sensor2
admin.site.register(Sensor2)
from .models import Sensor1
admin.site.register(Sensor1)
from .models import(Settings)
admin.site.register(Settings)
from .models import Alarm
admin.site.register(Alarm)